#!/bin/bash
# Run every (optimizer, run) unit sequentially, skipping units whose result
# file already exists. Set JOBS to run several units at once (each unit uses
# OMP_NUM_THREADS threads). Example:
#   JOBS=8 OMP_NUM_THREADS=2 ./run_all.sh            # all 19 optimizers
#   JOBS=4 OMP_NUM_THREADS=4 ./run_all.sh GWO HHO    # a subset
set -euo pipefail
cd "$(dirname "$0")"
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-2} MKL_NUM_THREADS=${OMP_NUM_THREADS:-2} OPENBLAS_NUM_THREADS=${OMP_NUM_THREADS:-2}
JOBS=${JOBS:-1}
ALGOS=$(python -c "from ucec_app.baselines import ALGORITHMS; print(' '.join(ALGORITHMS))")
[ $# -ge 1 ] && ALGOS="$*"
mkdir -p logs
running=0
for ALG in $ALGOS; do
  for RUN in $(seq 0 19); do
    python -m ucec_app.nested_cv --algorithm "$ALG" --run "$RUN" > "logs/unit-${ALG}-${RUN}.log" 2>&1 &
    running=$((running + 1))
    if [ "$running" -ge "$JOBS" ]; then wait -n; running=$((running - 1)); fi
  done
done
wait
echo "all units finished; now run: python -m ucec_app.aggregate"
