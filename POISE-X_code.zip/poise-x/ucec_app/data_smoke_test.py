"""
Real-data smoke test: load the cohort cache, build the fixed outer 5-fold
split, fit the candidate pool on outer fold 0's training rows, and time a
handful of fitness evaluations to measure the per-evaluation cost.
"""

from __future__ import annotations

import time

import numpy as np
from sklearn.model_selection import StratifiedKFold

from ucec_app.data import load_dataset
from ucec_app.feature_selection import FitnessConfig, N_CLASSIFIERS, make_fitness_fn
from ucec_app.prefilter import PrefilterConfig, fit_feature_pool


def main(k_per_block: int = 500, n_evals: int = 5, seed: int = 0) -> None:
    t0 = time.time()
    ds = load_dataset()
    print(f"loaded {ds.n} patients in {time.time()-t0:.1f}s; "
          f"classes={dict(zip(ds.class_names, np.bincount(ds.y, minlength=4).tolist()))}")
    for k, b in ds.blocks.items():
        print(f"  {k:6s}: {b.X.shape}")

    outer = StratifiedKFold(n_splits=5, shuffle=True, random_state=seed)
    train_idx, test_idx = next(iter(outer.split(np.zeros(ds.n), ds.y)))
    print(f"\nouter fold 0: {len(train_idx)} train / {len(test_idx)} test; "
          f"test class counts={np.bincount(ds.y[test_idx], minlength=4).tolist()}")

    t0 = time.time()
    pool = fit_feature_pool(ds, train_idx, PrefilterConfig(k_per_block=k_per_block))
    print(f"prefilter (anova, k={k_per_block}/block) in {time.time()-t0:.1f}s -> N={pool.n_features}: "
          + ", ".join(f"{b}={len(c)}" for b, c in pool.columns.items()))

    X_tr = pool.transform(ds, train_idx)
    y_tr = ds.y[train_idx]
    assert not np.isnan(X_tr).any(), "NaNs left after prefilter/imputation"
    fitness = make_fitness_fn(X_tr, y_tr, FitnessConfig(n_features=pool.n_features, k_inner=3, random_state=seed))

    rng = np.random.default_rng(seed)
    print(f"\ntiming {n_evals} fitness evaluations (dim={pool.n_features + N_CLASSIFIERS}):")
    for i in range(n_evals):
        x = rng.random(pool.n_features + N_CLASSIFIERS)
        n_sel = int((x[:pool.n_features] > 0.5).sum())
        clfs = int((x[pool.n_features:] > 0.5).sum())
        t0 = time.time()
        f = fitness(x)
        print(f"  eval {i}: F={f:.4f}  |S|={n_sel}  classifiers={clfs}  {time.time()-t0:.1f}s")


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--k", type=int, default=500)
    ap.add_argument("--n-evals", type=int, default=5)
    args = ap.parse_args()
    main(k_per_block=args.k, n_evals=args.n_evals)
