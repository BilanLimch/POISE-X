"""
No-feature-selection reference: every classifier trained on the FULL in-fold
candidate pool (all N = 2,505 prefiltered features), evaluated on the outer
test fold, same 5 outer folds / prefilter / z-score protocol as nested_cv.py.

    python -m ucec_app.full_pool_baseline [--k-per-block 500] [--seed 0]

Answers "what does the wrapper search buy us over simply using the whole
ANOVA pool?" -- without it, a high wrapper score could just reflect the
prefilter.  Writes results/summary/full_pool_baseline.tsv (per fold) and
prints the mean +/- std per classifier.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score

from ucec_app.data import CLASS_NAMES, load_dataset
from ucec_app.feature_selection import CLASSIFIER_NAMES
from ucec_app.nested_cv import RESULTS_DIR, _final_model_predict, outer_folds
from ucec_app.prefilter import PrefilterConfig, fit_feature_pool

MODELS: dict[str, list[str]] = {name: [name] for name in CLASSIFIER_NAMES}
MODELS["SVM+LR (soft vote)"] = ["SVM", "LogisticRegression"]
MODELS["all five (soft vote)"] = list(CLASSIFIER_NAMES)


def main(k_per_block: int, seed: int, out_dir: Path) -> None:
    ds = load_dataset()
    rows = []
    for fold, (tr, te) in enumerate(outer_folds(ds)):
        pool = fit_feature_pool(ds, tr, PrefilterConfig(k_per_block=k_per_block))
        X_tr, X_te = pool.transform(ds, tr), pool.transform(ds, te)
        y_tr, y_te = ds.y[tr], ds.y[te]
        for label, clfs in MODELS.items():
            pred, proba = _final_model_predict(clfs, X_tr, y_tr, X_te, seed)
            rows.append({
                "model": label, "fold": fold, "N": pool.n_features,
                "macro_f1": f1_score(y_te, pred, average="macro"),
                "macro_auc": roc_auc_score(y_te, proba, multi_class="ovr", average="macro"),
                "accuracy": accuracy_score(y_te, pred),
                **{f"f1_{c}": v for c, v in zip(CLASS_NAMES, f1_score(y_te, pred, average=None, labels=range(4)))},
            })
        print(f"fold {fold} done (N={pool.n_features})")
    df = pd.DataFrame(rows)
    out_dir.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_dir / "full_pool_baseline.tsv", sep="\t", index=False)
    g = df.groupby("model", sort=False)
    summ = pd.DataFrame({
        "macro_f1": g["macro_f1"].mean().round(3).astype(str) + " +/- " + g["macro_f1"].std().round(3).astype(str),
        "macro_auc": g["macro_auc"].mean().round(3).astype(str) + " +/- " + g["macro_auc"].std().round(3).astype(str),
        "accuracy": g["accuracy"].mean().round(3).astype(str) + " +/- " + g["accuracy"].std().round(3).astype(str),
        "f1_POLE": g["f1_UCEC_POLE"].mean().round(3),
    })
    print(f"\nAll {df['N'].iloc[0]} candidate features, 5 outer folds, mean +/- std:\n")
    print(summ.to_string())
    summ.to_csv(out_dir / "full_pool_baseline_summary.tsv", sep="\t")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--k-per-block", type=int, default=500)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", type=Path, default=RESULTS_DIR / "summary")
    a = ap.parse_args()
    main(a.k_per_block, a.seed, a.out)
