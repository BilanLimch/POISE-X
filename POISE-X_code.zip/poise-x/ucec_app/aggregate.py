"""
Collect the per-unit JSONs written by ``nested_cv.py`` into the study's
summary tables.

    python -m ucec_app.aggregate [--results results] [--out results/summary]

Outputs (TSV unless noted):
  runs.tsv                one row per (algorithm, fold, seed): test metrics,
                          |S|, best F, classifiers, wall time
  summary.tsv             per-algorithm mean / std / median of every metric
  stats_macro_f1.json     Friedman over all algorithms on paired (fold,
                          seed) blocks, then the best-mean algorithm vs each
                          other one with paired Wilcoxon + Holm correction
                          (NB: picking the best on the same outer folds is
                          model selection on test data; report all rows)
  feature_frequency.tsv   EVERY feature ever selected, one column per
                          algorithm with selected-count / in-pool-count.
                          No stability cut-off is applied here; choose one
                          after inspecting the table.
  classifier_frequency.tsv how often each classifier was in the final
                          ensemble, per algorithm
  jaccard.tsv             mean pairwise Jaccard similarity of selected
                          feature sets across an algorithm's runs
  curves.tsv              mean / std best-so-far F per algorithm at each
                          evaluation checkpoint (for convergence plots)
"""

from __future__ import annotations

import argparse
import itertools
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

from ucec_app.baselines import ALGORITHMS, tier_of
from ucec_app.data import load_dataset
from ucec_app.nested_cv import RESULTS_DIR, outer_folds
from ucec_app.prefilter import PrefilterConfig, fit_feature_pool

ALGO_ORDER = list(ALGORITHMS)   # study roster
METRICS = ["macro_f1", "macro_auc", "accuracy", "n_selected", "best_F", "search_seconds"]


def load_runs(results_dir: Path) -> tuple[pd.DataFrame, list[dict]]:
    records = []
    for p in sorted(results_dir.glob("*/fold*_seed*.json")):
        if p.parent.name in ALGO_ORDER:
            records.append(json.load(open(p)))
    if not records:
        raise SystemExit(f"no result files under {results_dir}")
    rows = []
    for r in records:
        rows.append({
            "algorithm": r["algorithm"], "fold": r["fold"], "seed": r["seed"],
            **{k: r["test_metrics"][k] for k in ("macro_f1", "macro_auc", "accuracy")},
            **{f"f1_{c}": v for c, v in r["test_metrics"]["per_class_f1"].items()},
            "n_selected": r["n_selected"], "best_F": r["best_F"],
            "classifiers": "+".join(r["classifiers"]), "search_seconds": r["search_seconds"],
        })
    df = pd.DataFrame(rows)
    df["algorithm"] = pd.Categorical(df["algorithm"], [a for a in ALGO_ORDER if a in set(df["algorithm"])])
    return df.sort_values(["algorithm", "fold", "seed"]).reset_index(drop=True), records


def holm(pvals: dict[str, float]) -> dict[str, float]:
    items = sorted(pvals.items(), key=lambda kv: kv[1])
    m, adj, running = len(items), {}, 0.0
    for i, (k, p) in enumerate(items):
        running = max(running, (m - i) * p)
        adj[k] = min(1.0, running)
    return adj


def statistics(df: pd.DataFrame, metric: str = "macro_f1") -> dict:
    wide = df.pivot_table(index=["fold", "seed"], columns="algorithm", values=metric, observed=True)
    complete = wide.dropna()
    out = {"metric": metric, "n_blocks_complete": int(len(complete)), "algorithms": list(map(str, wide.columns))}
    if len(complete) >= 2 and wide.shape[1] >= 3:
        fr = stats.friedmanchisquare(*[complete[a].to_numpy() for a in complete.columns])
        out["friedman"] = {"statistic": float(fr.statistic), "p": float(fr.pvalue)}
    if len(complete) >= 2 and wide.shape[1] >= 2:
        best = str(complete.mean().idxmax())
        out["best_by_mean"] = best
        raw = {}
        for a in complete.columns:
            if a == best:
                continue
            d = complete[best].to_numpy() - complete[a].to_numpy()
            raw[str(a)] = 1.0 if np.all(d == 0) else float(stats.wilcoxon(complete[best], complete[a]).pvalue)
        adj = holm(raw)
        out["best_vs"] = {a: {"wilcoxon_p": raw[a], "holm_p": adj[a],
                              "mean_diff": float((complete[best] - complete[a]).mean())} for a in raw}
    return out


def feature_frequency(records: list[dict], k_per_block: int) -> pd.DataFrame:
    """selected-count and in-pool-count per feature per algorithm; no threshold."""
    ds = load_dataset()
    folds = outer_folds(ds)
    pool_by_fold = {k: set(fit_feature_pool(ds, tr, PrefilterConfig(k_per_block=k_per_block)).feature_names)
                    for k, (tr, _) in enumerate(folds)}
    sel = defaultdict(lambda: defaultdict(int))
    in_pool = defaultdict(lambda: defaultdict(int))
    n_runs = defaultdict(int)
    for r in records:
        a = r["algorithm"]
        n_runs[a] += 1
        for f in pool_by_fold[r["fold"]]:
            in_pool[a][f] += 1
        for f in r["selected_features"]:
            sel[a][f] += 1
    algos = [a for a in ALGO_ORDER if a in n_runs]
    feats = sorted({f for a in algos for f in sel[a]})
    rows = []
    for f in feats:
        row = {"feature": f, "block": f.split(":", 1)[0]}
        for a in algos:
            row[f"{a}_selected"] = sel[a].get(f, 0)
            row[f"{a}_in_pool"] = in_pool[a].get(f, 0)
            row[f"{a}_freq_of_runs"] = sel[a].get(f, 0) / n_runs[a]
            row[f"{a}_freq_of_pool"] = sel[a].get(f, 0) / in_pool[a][f] if in_pool[a].get(f) else np.nan
        row["max_freq_of_runs"] = max(row[f"{a}_freq_of_runs"] for a in algos)
        rows.append(row)
    return pd.DataFrame(rows).sort_values(["max_freq_of_runs", "feature"], ascending=[False, True])


def classifier_frequency(records: list[dict]) -> pd.DataFrame:
    cnt = defaultdict(lambda: defaultdict(int))
    n_runs = defaultdict(int)
    for r in records:
        n_runs[r["algorithm"]] += 1
        for c in r["classifiers"]:
            cnt[r["algorithm"]][c] += 1
        cnt[r["algorithm"]]["__ensemble_size__"] += len(r["classifiers"])
    rows = []
    for a in [x for x in ALGO_ORDER if x in n_runs]:
        row = {"algorithm": a, "n_runs": n_runs[a]}
        for c in ("RF", "XGBoost", "SVM", "LogisticRegression", "KNN"):
            row[c] = cnt[a].get(c, 0) / n_runs[a]
        row["mean_ensemble_size"] = cnt[a]["__ensemble_size__"] / n_runs[a]
        rows.append(row)
    return pd.DataFrame(rows)


def jaccard(records: list[dict]) -> pd.DataFrame:
    sets = defaultdict(list)
    for r in records:
        sets[r["algorithm"]].append(set(r["selected_features"]))
    rows = []
    for a in [x for x in ALGO_ORDER if x in sets]:
        js = [len(s & t) / len(s | t) for s, t in itertools.combinations(sets[a], 2) if s | t]
        rows.append({"algorithm": a, "n_runs": len(sets[a]), "mean_jaccard": np.mean(js) if js else np.nan,
                     "std_jaccard": np.std(js) if js else np.nan})
    return pd.DataFrame(rows)


def curves(records: list[dict]) -> pd.DataFrame:
    by_algo = defaultdict(list)
    for r in records:
        by_algo[r["algorithm"]].append(dict(r["curve"]))
    rows = []
    for a, runs in by_algo.items():
        checkpoints = sorted(set.intersection(*[set(c) for c in runs]))
        for e in checkpoints:
            vals = [c[e] for c in runs]
            rows.append({"algorithm": a, "evals": e, "mean_best_F": np.mean(vals), "std_best_F": np.std(vals), "n_runs": len(vals)})
    return pd.DataFrame(rows)


def main(results_dir: Path, out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    df, records = load_runs(results_dir)
    df.to_csv(out_dir / "runs.tsv", sep="\t", index=False)
    summary = df.groupby("algorithm", observed=True)[METRICS].agg(["mean", "std", "median"])
    summary.columns = [f"{m}_{s}" for m, s in summary.columns]
    summary.insert(0, "n_runs", df.groupby("algorithm", observed=True).size())
    summary.insert(0, "tier", [tier_of(a) for a in summary.index])
    summary.to_csv(out_dir / "summary.tsv", sep="\t")
    with open(out_dir / "stats_macro_f1.json", "w") as f:
        json.dump(statistics(df, "macro_f1"), f, indent=2)
    k = records[0]["protocol"]["k_per_block"]
    feature_frequency(records, k).to_csv(out_dir / "feature_frequency.tsv", sep="\t", index=False)
    classifier_frequency(records).to_csv(out_dir / "classifier_frequency.tsv", sep="\t", index=False)
    jaccard(records).to_csv(out_dir / "jaccard.tsv", sep="\t", index=False)
    curves(records).to_csv(out_dir / "curves.tsv", sep="\t", index=False)

    print(f"{len(records)} runs from {results_dir}\n")
    print(summary[["tier", "n_runs", "macro_f1_mean", "macro_f1_std", "macro_auc_mean", "accuracy_mean", "n_selected_mean", "search_seconds_mean"]].round(3).to_string())
    print(f"\nwritten to {out_dir}/")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", type=Path, default=RESULTS_DIR)
    ap.add_argument("--out", type=Path, default=None)
    a = ap.parse_args()
    main(a.results, a.out or a.results / "summary")
