"""
Joint feature + classifier selection wrapper for the UCEC subtyping pipeline.

full design this implements. Summary:

- Chromosome is (N+5)-dimensional, each entry in [0, 1]. All algorithms
  compared in this project search directly
  in this box-constrained continuous space -- so binarizing by thresholding
  a position at 0.5 is equivalent to a "sigmoid + threshold"
  description (a sigmoid squash is only needed when the underlying search is
  unbounded; here the algorithms already clip to [0, 1]).
- First N entries select features; last 5 select which of the 5 candidate
  classifiers participate (>=1 selected -> ensemble of those; 0 selected ->
  one random classifier).
- Fitness: F = alpha*(1 - macro_f1) + (1 - alpha)*|S|/N,
  alpha = 0.9, minimized. This is the "inner CV" -- callers must restrict
  X, y to the current outer-training fold before calling `make_fitness_fn`
 ; this module has no knowledge of outer folds.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedKFold
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from xgboost import XGBClassifier

CLASSIFIER_NAMES: tuple[str, ...] = ("RF", "XGBoost", "SVM", "LogisticRegression", "KNN")
N_CLASSIFIERS = len(CLASSIFIER_NAMES)


def build_classifier(name: str, random_state: int):
    if name == "RF":
        return RandomForestClassifier(random_state=random_state)
    if name == "XGBoost":
        # 50 trees instead of the library default of 100 (cost of a fitness evaluation).
        # XGBoost was >80% of every fitness evaluation's cost (8.2 s of ~10 s
        # at |S|=1250); the other four classifiers keep library defaults.
        # device="cpu" pinned explicitly: on the GPU nodes the CUDA build of
        # xgboost 3.x otherwise probed CUDA and crashed with cudaErrorNoDevice.
        return XGBClassifier(n_estimators=50, random_state=random_state, eval_metric="mlogloss", device="cpu")
    if name == "SVM":
        return SVC(kernel="rbf", probability=True, random_state=random_state)
    if name == "LogisticRegression":
        return LogisticRegression(max_iter=1000, random_state=random_state)
    if name == "KNN":
        return KNeighborsClassifier()
    raise ValueError(f"unknown classifier name: {name!r}")


def decode_chromosome(x: np.ndarray, n_features: int) -> tuple[np.ndarray, np.ndarray]:
    """Threshold-binarize an (N+5)-dim chromosome into (feature_mask, classifier_mask)."""
    binary = x > 0.5
    return binary[:n_features], binary[n_features:]


def resolve_classifier_ensemble(classifier_mask: np.ndarray, rng: np.random.Generator) -> list[str]:
    """>=1 selected -> those classifiers; all-zero -> one random pick."""
    selected = [name for name, bit in zip(CLASSIFIER_NAMES, classifier_mask) if bit]
    if not selected:
        selected = [str(rng.choice(CLASSIFIER_NAMES))]
    return selected


def _ensemble_predict(clf_names: list[str], X_tr, y_tr, X_te, random_state: int) -> np.ndarray:
    """Train each named classifier on (X_tr, y_tr), soft-vote their probabilities on X_te."""
    proba_sum = None
    classes_ = None
    for name in clf_names:
        clf = build_classifier(name, random_state)
        clf.fit(X_tr, y_tr)
        proba = clf.predict_proba(X_te)
        if classes_ is None:
            classes_ = clf.classes_
        elif not np.array_equal(classes_, clf.classes_):
            # Align columns if a fold happened to be missing a class for one
            # classifier but not another -- shouldn't happen with stratified
            # folds on all four subtypes present, but guard against it.
            aligned = np.zeros((proba.shape[0], len(classes_)))
            for j, c in enumerate(clf.classes_):
                aligned[:, list(classes_).index(c)] = proba[:, j]
            proba = aligned
        proba_sum = proba if proba_sum is None else proba_sum + proba
    return classes_[np.argmax(proba_sum, axis=1)]


@dataclass
class FitnessConfig:
    n_features: int
    alpha: float = 0.9
    k_inner: int = 3
    random_state: int = 0


def make_fitness_fn(X: np.ndarray, y: np.ndarray, config: FitnessConfig) -> Callable[[np.ndarray], float]:
    """Build the section-4.3 fitness function over an outer-training fold.

    `X`, `y` must already be restricted to the current outer-training fold
    and to the candidate feature pool computed from that same
    fold -- this function performs no prefiltering itself.
    """
    n_features = config.n_features
    if X.shape[1] != n_features:
        raise ValueError(f"X has {X.shape[1]} columns, expected n_features={n_features}")

    rng = np.random.default_rng(config.random_state)
    skf = StratifiedKFold(n_splits=config.k_inner, shuffle=True, random_state=config.random_state)
    # Fold assignment is fixed once per fitness_fn instance (i.e. per run), not
    # reshuffled per call, so the fitness is deterministic within a run.
    splits = list(skf.split(X, y))

    def fitness(x: np.ndarray) -> float:
        feature_mask, classifier_mask = decode_chromosome(x, n_features)
        n_selected = int(feature_mask.sum())
        if n_selected == 0:
            return 1.0  # worst-case F: no features to fit a model with
        clf_names = resolve_classifier_ensemble(classifier_mask, rng)

        f1_scores = []
        for train_idx, test_idx in splits:
            X_tr, X_te = X[train_idx][:, feature_mask], X[test_idx][:, feature_mask]
            y_tr, y_te = y[train_idx], y[test_idx]

            scaler = StandardScaler().fit(X_tr)
            X_tr, X_te = scaler.transform(X_tr), scaler.transform(X_te)

            y_pred = _ensemble_predict(clf_names, X_tr, y_tr, X_te, config.random_state)
            f1_scores.append(f1_score(y_te, y_pred, average="macro"))

        macro_f1 = float(np.mean(f1_scores))
        penalty = n_selected / n_features
        return config.alpha * (1.0 - macro_f1) + (1.0 - config.alpha) * penalty

    return fitness
