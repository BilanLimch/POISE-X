"""
End-to-end smoke test on synthetic data shaped like TCGA-UCEC (~500 samples,
imbalanced 4-class molecular subtype, high-dimensional feature pool).

This validates that feature_selection.py + baselines.py work together and
that all benchmarked algorithms run to completion
and improve over a random baseline. It does NOT implement the full nested-CV
protocol or stability selection -- those need
real TCGA-UCEC data (see nested_cv.py and consensus_validation.py).
Run reduced-scale (small pop/epoch) purely to check correctness quickly.
"""

from __future__ import annotations

import time

import numpy as np
from sklearn.datasets import make_classification

from ucec_app.baselines import ALGORITHMS
from ucec_app.feature_selection import FitnessConfig, N_CLASSIFIERS, make_fitness_fn


def make_synthetic_ucec_like(seed: int = 0):
    """~500 samples, 4 classes with TCGA-UCEC-like imbalance (7/28/39/26%), 300 candidate features."""
    weights = [0.07, 0.28, 0.39, 0.26]
    X, y = make_classification(
        n_samples=500, n_features=300, n_informative=20, n_redundant=10,
        n_classes=4, n_clusters_per_class=1, weights=weights, flip_y=0.05,
        random_state=seed,
    )
    return X, y


def main():
    X, y = make_synthetic_ucec_like()
    n_features = X.shape[1]
    dim = n_features + N_CLASSIFIERS

    config = FitnessConfig(n_features=n_features, alpha=0.9, k_inner=3, random_state=0)
    fitness_fn = make_fitness_fn(X, y, config)

    # Development-only setting.  The standard experiment uses population=50
    # and max_fes=5_000; keep smoke tests small but use the same
    # generation-budget shape.
    pop_size, max_fes = 50, 500
    print(f"dim={dim} (N={n_features} features + {N_CLASSIFIERS} classifiers), max_fes={max_fes}\n")

    for name, runner in ALGORITHMS.items():
        t0 = time.time()
        kwargs = dict(dim=dim, fitness_fn=fitness_fn, max_fes=max_fes, seed=42)
        kwargs["pop_size"] = pop_size
        best_x, best_f = runner(**kwargs)
        elapsed = time.time() - t0
        n_selected = int((best_x[:n_features] > 0.5).sum())
        print(f"{name:8s}  F={best_f:.4f}  n_features_selected={n_selected:4d}  ({elapsed:.1f}s)")


if __name__ == "__main__":
    main()
