"""
Unified runner interface over the mealpy-based metaheuristics benchmarked in
this study (four literature baselines HHO, GWO, CSA, ACOR plus fifteen further
optimisers). CS and ACO's continuous-domain formulations are CSA
(Cuckoo Search Algorithm) and ACOR (Ant Colony Optimization for continuous
domains) respectively -- mealpy has no combinatorial ACO, and the whole
pipeline operates in continuous [0, 1]^(N+5) space with
threshold-binarization at evaluation time, so the continuous variants are
the correct match, not a compromise.

Every runner below takes the same (dim, fitness_fn, pop_size, max_fes, seed)
shape and returns (best_solution: np.ndarray, best_fitness: float), so that
the nested-CV harness (nested_cv.py) can treat all six algorithms
identically -- this is the fairness requirement made
concrete in code.

All algorithms use the same population size so that "one generation" costs
the same number of fitness evaluations across every algorithm compared.
"""

from __future__ import annotations

import math
from typing import Callable

import numpy as np
from mealpy import FloatVar
from mealpy.swarm_based.ACOR import OriginalACOR
from mealpy.swarm_based.CSA import OriginalCSA
from mealpy.swarm_based.GWO import OriginalGWO
from mealpy.swarm_based.HHO import OriginalHHO

FitnessFn = Callable[[np.ndarray], float]

# Shared study protocol: population 50, 5,000 evaluations per search, 20 independent
# searches per algorithm (5 outer folds x 4 seeds), inner 3-fold CV,
# XGBoost with 50 trees (see feature_selection.py).
STANDARD_POP_SIZE = 50
STANDARD_MAX_FES = 5_000


def _run_mealpy(model, dim: int, fitness_fn: FitnessFn, max_fes: int, pop_size: int, seed: int | None) -> tuple[np.ndarray, float]:
    """Run a MEALPY baseline using precisely the shared FE budget.

    MEALPY evaluates the initial population before its first epoch.  ACOR then
    evaluates its ``sample_count`` newly generated samples per epoch (25 by
    default), whereas the other selected baselines generate at least one
    population's worth.  The epoch count is consequently derived from the
    algorithm's actual offspring batch size; the budget guard below handles
    algorithms such as HHO whose branch-specific updates can create extras.
    """
    if dim < 1:
        raise ValueError("dim must be positive")
    if pop_size < 2:
        raise ValueError("pop_size must be at least 2")
    if max_fes < 2 * pop_size:
        raise ValueError(
            "MEALPY baselines require enough budget for initialization and "
            "one update generation (max_fes >= 2 * pop_size)"
        )
    if max_fes % pop_size:
        raise ValueError(
            "max_fes must be an exact multiple of pop_size so all baseline "
            "algorithms receive the same FE budget"
        )

    offspring_per_epoch = model.sample_count if isinstance(model, OriginalACOR) else pop_size
    epoch = math.ceil((max_fes - pop_size) / offspring_per_epoch)
    model.epoch, model.pop_size = epoch, pop_size
    problem = {
        "obj_func": fitness_fn,
        "bounds": FloatVar(lb=[0.0] * dim, ub=[1.0] * dim),
        "minmax": "min",
        "log_to": None,
    }
    # MEALPY checks `max_fe` only after a whole generation.  Some algorithms
    # (notably HHO) create more than one candidate per agent, so its internal
    # counter can overshoot even with a generation count chosen carefully.
    # Guard the *actual expensive objective* as well: post-budget candidates
    # receive +inf and therefore cannot enter the population or alter g_best.
    evaluations = 0

    def budgeted_fitness(x: np.ndarray) -> float:
        nonlocal evaluations
        if evaluations >= max_fes:
            return float("inf")
        evaluations += 1
        return float(fitness_fn(x))

    problem["obj_func"] = budgeted_fitness
    g_best = model.solve(problem, seed=seed, termination={"max_fe": max_fes})
    if evaluations != max_fes:
        raise RuntimeError(
            f"{model.__class__.__name__} used {evaluations} real FEs; "
            f"expected {max_fes}"
        )
    return np.asarray(g_best.solution), float(g_best.target.fitness)


def run_hho(dim: int, fitness_fn: FitnessFn, max_fes: int = STANDARD_MAX_FES, pop_size: int = STANDARD_POP_SIZE, seed: int | None = None):
    return _run_mealpy(OriginalHHO(), dim, fitness_fn, max_fes, pop_size, seed)


def run_gwo(dim: int, fitness_fn: FitnessFn, max_fes: int = STANDARD_MAX_FES, pop_size: int = STANDARD_POP_SIZE, seed: int | None = None):
    return _run_mealpy(OriginalGWO(), dim, fitness_fn, max_fes, pop_size, seed)


def run_cs(dim: int, fitness_fn: FitnessFn, max_fes: int = STANDARD_MAX_FES, pop_size: int = STANDARD_POP_SIZE, seed: int | None = None):
    """Cuckoo Search baseline (mealpy's OriginalCSA)."""
    return _run_mealpy(OriginalCSA(), dim, fitness_fn, max_fes, pop_size, seed)


def run_aco(dim: int, fitness_fn: FitnessFn, max_fes: int = STANDARD_MAX_FES, pop_size: int = STANDARD_POP_SIZE, seed: int | None = None):
    """Ant Colony baseline (mealpy's OriginalACOR, the continuous-domain ACO variant)."""
    return _run_mealpy(OriginalACOR(), dim, fitness_fn, max_fes, pop_size, seed)


# ---------------------------------------------------------------------------
# Benchmark roster: every entry is mealpy's "Original*"
# class with library defaults, run through the same `_run_mealpy` budget guard.
# (module, class); year = original publication of the algorithm.
MEALPY_ROSTER: dict[str, tuple[str, str]] = {
    # existing baselines
    "HHO":  ("swarm_based.HHO", "OriginalHHO"),      # 2019
    "GWO":  ("swarm_based.GWO", "OriginalGWO"),      # 2014
    "CS":   ("swarm_based.CSA", "OriginalCSA"),      # 2009
    "ACO":  ("swarm_based.ACOR", "OriginalACOR"),    # 2008 (continuous ACO)
    # physics-based
    "RIME": ("physics_based.RIME", "OriginalRIME"),  # 2023
    "EO":   ("physics_based.EO", "OriginalEO"),      # 2020
    # swarm-based
    "MPA":  ("swarm_based.MPA", "OriginalMPA"),      # 2020
    "AO":   ("swarm_based.AO", "OriginalAO"),        # 2021
    "ARO":  ("swarm_based.ARO", "OriginalARO"),      # 2022
    "GJO":  ("swarm_based.GJO", "OriginalGJO"),      # 2022
    "SCSO": ("swarm_based.SCSO", "OriginalSCSO"),    # 2022
    "FOX":  ("swarm_based.FOX", "OriginalFOX"),      # 2023 (replaces COA: mealpy 3.0.3 OriginalCOA raises IndexError)
    "WOA":  ("swarm_based.WOA", "OriginalWOA"),      # 2016
    "PSO":  ("swarm_based.PSO", "OriginalPSO"),      # 1995
    # bio / math / evolutionary
    "SMA":  ("bio_based.SMA", "OriginalSMA"),        # 2020
    "AOA":  ("math_based.AOA", "OriginalAOA"),       # 2021
    "INFO": ("math_based.INFO", "OriginalINFO"),     # 2022
    "GBO":  ("math_based.GBO", "OriginalGBO"),       # 2020
    "DE":   ("evolutionary_based.DE", "OriginalDE"), # 1997
}


# Tier of each roster entry in the study's result tables:
#   "baseline"  -- the four optimizers with published cancer-omics applications,
#                  kept exactly as configured there (published precedents on
#                  similar omics data);
#   "candidate" -- additional mealpy algorithms screened on this pipeline; the
#                  best performer becomes the pipeline's default search algorithm.
LITERATURE_BASELINES: tuple[str, ...] = ("HHO", "GWO", "CS", "ACO")


def tier_of(name: str) -> str:
    return "baseline" if name in LITERATURE_BASELINES else "candidate"


def _make_model(name: str, pop_size: int):
    import importlib
    module, cls = MEALPY_ROSTER[name]
    model_cls = getattr(importlib.import_module(f"mealpy.{module}"), cls)
    if name == "ACO":   # see run_aco: sample_count, not pop_size, is ACOR's per-epoch batch
        return model_cls()
    return model_cls()


def make_runner(name: str) -> Callable[..., tuple[np.ndarray, float]]:
    def run(dim: int, fitness_fn: FitnessFn, max_fes: int = STANDARD_MAX_FES,
            pop_size: int = STANDARD_POP_SIZE, seed: int | None = None):
        return _run_mealpy(_make_model(name, pop_size), dim, fitness_fn, max_fes, pop_size, seed)
    run.__name__ = f"run_{name.lower()}"
    return run


ALGORITHMS: dict[str, Callable[..., tuple[np.ndarray, float]]] = {name: make_runner(name) for name in MEALPY_ROSTER}
