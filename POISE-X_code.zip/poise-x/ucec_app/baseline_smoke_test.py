"""Fast, deterministic FE-budget check for every UCEC search algorithm."""

from __future__ import annotations

import numpy as np

from ucec_app.baselines import ALGORITHMS


def main() -> None:
    # Development-only protocol: smaller than the study protocol
    # (population=50, max_fes=5_000) but still exercises ten generations.
    dim, pop_size, max_fes = 5, 50, 500

    for name, runner in ALGORITHMS.items():
        calls = 0

        def sphere(x: np.ndarray) -> float:
            nonlocal calls
            calls += 1
            return float(np.dot(x, x))

        kwargs = {"dim": dim, "fitness_fn": sphere, "max_fes": max_fes, "seed": 7}
        kwargs["pop_size"] = pop_size
        _, best_fitness = runner(**kwargs)
        assert calls == max_fes, f"{name}: expected {max_fes} FEs, got {calls}"
        assert np.isfinite(best_fitness), f"{name}: non-finite best fitness"
        print(f"{name}: {calls} FEs, best={best_fitness:.6e}")


if __name__ == "__main__":
    main()
