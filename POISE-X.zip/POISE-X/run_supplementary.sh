#!/bin/bash
# Supplementary analyses. Requires the main
# experiment (run_all.sh, full_pool_baseline, aggregate) to have been run.
# The 160 search units skip existing result files, so the script can be restarted.
# Set JOBS to run several search units at once (each uses OMP_NUM_THREADS threads).
#   JOBS=8 OMP_NUM_THREADS=2 ./run_supplementary.sh
set -euo pipefail
cd "$(dirname "$0")"
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-2} MKL_NUM_THREADS=${OMP_NUM_THREADS:-2} OPENBLAS_NUM_THREADS=${OMP_NUM_THREADS:-2}
JOBS=${JOBS:-1}
mkdir -p logs
running=0
for ALG in ACO GWO; do
  for RUN in $(seq 0 19); do
    for VAR in "--omics-only" "--alpha 0.8" "--alpha 0.95" "--alpha 0.99"; do
      tag=$(echo "$VAR" | tr -d ' -')
      python -m ucec_app.search_variant --algorithm "$ALG" --run "$RUN" $VAR > "logs/sensitivity-${ALG}-${RUN}-${tag}.log" 2>&1 &
      running=$((running + 1))
      if [ "$running" -ge "$JOBS" ]; then wait -n; running=$((running - 1)); fi
    done
  done
done
wait
# Reference models are fitted with the default number of linear-algebra threads, as in the main experiment.
unset OMP_NUM_THREADS MKL_NUM_THREADS OPENBLAS_NUM_THREADS
python scripts/extract_mlh1_probes.py
python -m ucec_app.reference_baselines
python -m ucec_app.selection_rule
python -m ucec_app.jaccard_chance
python -m ucec_app.sensitivity_aggregate
