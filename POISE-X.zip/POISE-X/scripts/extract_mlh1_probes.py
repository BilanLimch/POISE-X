"""
Extract the beta values of the 450K probes annotated to MLH1 from the raw
methylation file, for the MLH1 promoter-methylation indicator of the
clinical-classification surrogate.

The probe list ``data/mlh1_probes.tsv`` holds the 51 probes whose gene field
contains MLH1 in the GDC hg38 probe map
(https://gdc-hub.s3.us-east-1.amazonaws.com/download/HM450.hg38.manifest.gencode.v36.probeMap).
It can be rebuilt from a downloaded copy of that file with ``--probemap``.

    UCEC_RAW_DIR=/path/to/raw python scripts/extract_mlh1_probes.py
    # writes $UCEC_CACHE_DIR/mlh1_beta.tsv (default ./data)
"""
from __future__ import annotations

import argparse
import gzip
import os
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
RAW_DIR = Path(os.environ.get("UCEC_RAW_DIR", "raw"))
CACHE_DIR = Path(os.environ.get("UCEC_CACHE_DIR", REPO / "data"))
PROBES = REPO / "data" / "mlh1_probes.tsv"
METH_FILE = "TCGA-UCEC.methylation450.tsv.gz"


def rebuild_probe_list(probemap: Path) -> None:
    rows = []
    with open(probemap) as f:
        header = f.readline()
        for line in f:
            parts = line.rstrip("\n").split("\t")
            if "MLH1" in parts[1].split(","):
                rows.append(parts)
    rows.sort(key=lambda r: int(r[3]))
    with open(PROBES, "w") as f:
        f.write("id\tgene\tchrom\tchromStart\tchromEnd\tstrand\n")
        f.writelines("\t".join(r) + "\n" for r in rows)
    print(f"{len(rows)} MLH1 probes written to {PROBES}")


def extract() -> None:
    with open(PROBES) as f:
        next(f)
        wanted = {line.split("\t")[0] for line in f}
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    out_path = CACHE_DIR / "mlh1_beta.tsv"
    n = 0
    with gzip.open(RAW_DIR / METH_FILE, "rt") as fin, open(out_path, "w") as fout:
        fout.write(fin.readline())
        for line in fin:
            if line[:line.find("\t")] in wanted:
                fout.write(line)
                n += 1
                if n == len(wanted):
                    break
    print(f"{n} of {len(wanted)} probes written to {out_path}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--probemap", type=Path, help="rebuild data/mlh1_probes.tsv from this probe map first")
    a = ap.parse_args()
    if a.probemap:
        rebuild_probe_list(a.probemap)
    extract()
