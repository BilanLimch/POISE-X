"""
Summary and figure of the sensitivity searches.

Compares POISE-GWO and POISE-ACO at alpha = 0.8, 0.95, 0.99 and on the
omics-only pool with the main experiment (alpha = 0.9), which uses the same
folds and seeds, so that runs are paired. Reads ``results/<ALG>/`` and
``results/supplementary/<variant>/<ALG>/``; writes
``results/summary/sensitivity_searches.tsv`` and ``results/summary/alpha_sensitivity.pdf``.

    python -m ucec_app.sensitivity_aggregate
"""

from __future__ import annotations

import glob
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from scipy.stats import wilcoxon

from ucec_app.nested_cv import RESULTS_DIR

SUMMARY_DIR = RESULTS_DIR / "summary"
VARIANTS = [("alpha0.8", 0.8), ("main", 0.9), ("alpha0.95", 0.95), ("alpha0.99", 0.99), ("omics_only", 0.9)]
ALGS = ["GWO", "ACO"]
METRICS = ["macro_f1", "macro_auc", "accuracy", "n_selected", "best_F", "clin",
           "f1_UCEC_POLE", "f1_UCEC_MSI", "f1_UCEC_CN_LOW", "f1_UCEC_CN_HIGH"]


def load_runs(variant: str, alg: str) -> pd.DataFrame:
    root = RESULTS_DIR if variant == "main" else RESULTS_DIR / "supplementary" / variant
    rows = []
    for f in sorted(glob.glob(str(root / alg / "fold*_seed*.json"))):
        r = json.load(open(f))
        m = r["test_metrics"]
        rows.append({"fold": r["fold"], "seed": r["seed"], "macro_f1": m["macro_f1"], "macro_auc": m["macro_auc"],
                     "accuracy": m["accuracy"], "n_selected": r["n_selected"], "best_F": r["best_F"],
                     "clin": r["selected_per_block"].get("clin", 0),
                     **{"f1_" + k: v for k, v in m["per_class_f1"].items()}})
    return pd.DataFrame(rows)


def summarize() -> pd.DataFrame:
    out = []
    for variant, alpha in VARIANTS:
        for alg in ALGS:
            d = load_runs(variant, alg)
            if d.empty:
                continue
            row = {"variant": variant, "alpha": alpha, "algorithm": alg, "n_runs": len(d)}
            for c in METRICS:
                row[c + "_mean"], row[c + "_sd"] = d[c].mean(), d[c].std(ddof=1)
            if variant != "main":
                base = load_runs("main", alg).set_index(["fold", "seed"]).macro_f1
                diff = (d.set_index(["fold", "seed"]).macro_f1 - base).dropna()
                if len(diff) == len(d):
                    row["diff_vs_main"] = diff.mean()
                    row["wilcoxon_p_vs_main"] = wilcoxon(diff).pvalue if (diff != 0).any() else 1.0
                    row["fold_means_below_main"] = int((diff.groupby(level=0).mean() < 0).sum())
            out.append(row)
    return pd.DataFrame(out)


def reference_f1() -> float:
    fp = pd.read_csv(SUMMARY_DIR / "full_pool_baseline.tsv", sep="\t")
    return float(fp[fp.model == "LogisticRegression"].macro_f1.mean())


def alpha_figure(s: pd.DataFrame, ref: float) -> None:
    plt.rcParams.update({"font.size": 8, "axes.spines.top": False, "axes.spines.right": False,
                         "pdf.fonttype": 42, "savefig.dpi": 300})
    a = s[s.variant != "omics_only"]
    alphas = [0.8, 0.9, 0.95, 0.99]
    xpos = {v: i for i, v in enumerate(alphas)}
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(6.7, 2.6), gridspec_kw={"wspace": 0.32})
    for alg, col, mk, off in [("GWO", "#2a78d6", "o", -0.06), ("ACO", "#6f6e6a", "s", 0.06)]:
        d = a[a.algorithm == alg].sort_values("alpha")
        x = [xpos[v] + off for v in d.alpha]
        ax1.errorbar(x, d.n_selected_mean, yerr=d.n_selected_sd, color=col, marker=mk, ms=4, lw=1, capsize=2, label=f"POISE-{alg}")
        ax2.errorbar(x, d.macro_f1_mean, yerr=d.macro_f1_sd, color=col, marker=mk, ms=4, lw=1, capsize=2)
    ax2.axhline(ref, color="#8a8985", lw=0.8, ls=(0, (4, 2)))
    ax2.text(1.01, ref, "No selection\n+ LR", fontsize=6.5, ha="left", va="center",
             transform=ax2.get_yaxis_transform(), clip_on=False)
    for ax, lab, ylab in [(ax1, "a", "Panel size |S|"), (ax2, "b", "Macro-averaged $F_1$")]:
        ax.set_xticks(range(len(alphas)), [f"{v:g}" for v in alphas])
        ax.set_xlim(-0.4, len(alphas) - 0.6)
        ax.set_xlabel(r"Parsimony weight $\alpha$")
        ax.set_ylabel(ylab)
        ax.grid(True, axis="y", color="#e6e4df", lw=0.5)
        ax.text(-0.18, 1.02, lab, transform=ax.transAxes, fontweight="bold", fontsize=9)
    ax1.legend(frameon=False, loc="center left", bbox_to_anchor=(0.02, 0.55))
    fig.savefig(SUMMARY_DIR / "alpha_sensitivity.pdf", bbox_inches="tight", pad_inches=0.02)
    print("wrote", SUMMARY_DIR / "alpha_sensitivity.pdf")


def main() -> None:
    SUMMARY_DIR.mkdir(parents=True, exist_ok=True)
    s = summarize()
    s.to_csv(SUMMARY_DIR / "sensitivity_searches.tsv", sep="\t", index=False)
    pd.set_option("display.width", 250)
    show = ["variant", "algorithm", "n_runs", "macro_f1_mean", "macro_f1_sd", "macro_auc_mean", "n_selected_mean",
            "n_selected_sd", "best_F_mean"] + [c for c in ["diff_vs_main", "wilcoxon_p_vs_main", "fold_means_below_main"] if c in s]
    print(s[show].round(3).to_string(index=False))
    if (s.variant != "omics_only").sum() == 8:
        alpha_figure(s, reference_f1())


if __name__ == "__main__":
    main()
