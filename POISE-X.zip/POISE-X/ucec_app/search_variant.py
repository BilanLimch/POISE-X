"""
One unit of the sensitivity searches:
the nested-CV unit of ``ucec_app.nested_cv`` with two parameters exposed --
the fitness weight alpha and whether the five clinical variables enter the
candidate pool. Outer folds, prefilter, inner CV, seeds, population size,
budget and final refit are those of the main experiment.

    python -m ucec_app.search_variant --algorithm GWO --run 7 --alpha 0.95
    python -m ucec_app.search_variant --algorithm ACO --run 3 --omics-only

Results go to ``results/supplementary/<variant>/<algorithm>/fold<k>_seed<s>.json``
with variant ``alpha0.8``, ``alpha0.95``, ``alpha0.99`` or ``omics_only``.
With ``--alpha 0.9`` and clinical variables included, a unit reproduces the
corresponding unit of the main experiment exactly.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score

from ucec_app.baselines import ALGORITHMS, STANDARD_MAX_FES, STANDARD_POP_SIZE
from ucec_app.data import CLASS_NAMES, load_dataset
from ucec_app.feature_selection import (
    FitnessConfig, N_CLASSIFIERS, decode_chromosome, make_fitness_fn, resolve_classifier_ensemble,
)
from ucec_app.nested_cv import CURVE_EVERY, K_INNER, RESULTS_DIR, _final_model_predict, outer_folds, unit_from_run
from ucec_app.prefilter import PrefilterConfig, fit_feature_pool

SUPPLEMENTARY_DIR = RESULTS_DIR / "supplementary"


def variant_name(alpha: float, omics_only: bool) -> str:
    return "omics_only" if omics_only else f"alpha{alpha:g}"


def run_variant(algorithm: str, run: int, alpha: float = 0.9, omics_only: bool = False,
                max_fes: int = STANDARD_MAX_FES, out_dir: Path = SUPPLEMENTARY_DIR) -> dict:
    fold, seed = unit_from_run(run)
    out_path = Path(out_dir) / variant_name(alpha, omics_only) / algorithm / f"fold{fold}_seed{seed}.json"
    if out_path.exists():
        print(f"exists, skipping: {out_path}")
        return json.load(open(out_path))
    out_path.parent.mkdir(parents=True, exist_ok=True)

    t_start = time.time()
    ds = load_dataset()
    train_idx, test_idx = outer_folds(ds)[fold]
    y_tr, y_te = ds.y[train_idx], ds.y[test_idx]
    pool = fit_feature_pool(ds, train_idx, PrefilterConfig(k_per_block=500, include_clinical=not omics_only))
    X_tr, X_te = pool.transform(ds, train_idx), pool.transform(ds, test_idx)
    N = pool.n_features

    base_fitness = make_fitness_fn(X_tr, y_tr, FitnessConfig(n_features=N, alpha=alpha, k_inner=K_INNER, random_state=seed))
    curve: list[tuple[int, float]] = []
    state = {"evals": 0, "best": float("inf")}

    def fitness(x):
        f = base_fitness(x)
        state["evals"] += 1
        state["best"] = min(state["best"], f)
        if state["evals"] % CURVE_EVERY == 0 or state["evals"] == 1:
            curve.append((state["evals"], state["best"]))
        return f

    t_search = time.time()
    best_x, best_f = ALGORITHMS[algorithm](dim=N + N_CLASSIFIERS, fitness_fn=fitness, max_fes=max_fes,
                                           seed=seed, pop_size=STANDARD_POP_SIZE)
    search_seconds = time.time() - t_search
    curve.append((state["evals"], state["best"]))

    feat_mask, clf_mask = decode_chromosome(best_x, N)
    clf_names = resolve_classifier_ensemble(clf_mask, np.random.default_rng(seed))
    if feat_mask.sum() == 0:
        feat_mask = np.ones(N, dtype=bool)
    pred, proba = _final_model_predict(clf_names, X_tr[:, feat_mask], y_tr, X_te[:, feat_mask], seed)
    result = {
        "algorithm": algorithm, "fold": fold, "seed": seed, "run": run,
        "variant": variant_name(alpha, omics_only), "alpha": alpha, "omics_only": omics_only, "max_fes": max_fes,
        "N": int(N), "best_F": float(best_f), "evals_used": state["evals"],
        "n_selected": int(feat_mask.sum()),
        "selected_per_block": {b: int(feat_mask[s].sum()) for b, s in pool.block_slices.items()},
        "selected_features": pool.feature_names[feat_mask].tolist(), "classifiers": clf_names,
        "test_metrics": {
            "macro_f1": float(f1_score(y_te, pred, average="macro")),
            "macro_auc": float(roc_auc_score(y_te, proba, multi_class="ovr", average="macro")),
            "accuracy": float(accuracy_score(y_te, pred)),
            "per_class_f1": dict(zip(CLASS_NAMES, f1_score(y_te, pred, average=None, labels=range(4)).tolist())),
        },
        "curve": curve, "search_seconds": search_seconds, "total_seconds": time.time() - t_start,
    }
    with open(out_path, "w") as f:
        json.dump(result, f, indent=1)
    m = result["test_metrics"]
    print(f"{result['variant']} {algorithm} run{run}: F={best_f:.4f} |S|={result['n_selected']} clfs={clf_names} "
          f"test macro-F1={m['macro_f1']:.3f} AUC={m['macro_auc']:.3f} [{search_seconds / 60:.1f} min search]")
    return result


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--algorithm", required=True, choices=list(ALGORITHMS))
    ap.add_argument("--run", type=int, required=True, help="run index 0..19 (fold = run // 4, seed = 2026 + 98*run)")
    ap.add_argument("--alpha", type=float, default=0.9)
    ap.add_argument("--omics-only", action="store_true", help="leave the five clinical variables out of the pool")
    ap.add_argument("--max-fes", type=int, default=STANDARD_MAX_FES, help="evaluation budget (smaller for a quick check)")
    ap.add_argument("--out", type=Path, default=SUPPLEMENTARY_DIR)
    a = ap.parse_args()
    run_variant(a.algorithm, a.run, a.alpha, a.omics_only, a.max_fes, a.out)
