"""
Reference analyses that involve no search. All use the outer folds, the in-fold prefilter
and in-fold z-scoring of the main experiment; LR is the classifier of the
no-selection reference.

  * data layers: each omics block alone (500 prefiltered features), the full
    pool with one block left out, and the mutation block with one other block;
  * surrogate of the clinical molecular classification: POLE exonuclease-domain
    hotspot, mismatch-repair deficiency (MMR gene mutation or MLH1 promoter
    hypermethylation) and TP53 mutation, combined by the sequential ProMisE rule
    (MLH1 thresholds 0.2 / 0.3 / 0.4) or by LR;
  * omics-only pool: full-pool LR and ANOVA top-450 LR; clinical variables alone;
  * noise of the inner-fold macro-F1 estimate (3-fold CV, 20 inner partitions);
  * ANOVA rank of the clinical variables in every outer training fold.

Requires ``$UCEC_CACHE_DIR/mlh1_beta.tsv`` (``scripts/extract_mlh1_probes.py``).

    python -m ucec_app.reference_baselines
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.feature_selection import f_classif
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler

from ucec_app.data import CACHE_DIR, CLASS_NAMES, MUTATION_FILE, RAW_DIR, load_dataset, pick_primary_samples
from ucec_app.feature_selection import build_classifier
from ucec_app.nested_cv import RESULTS_DIR, outer_folds
from ucec_app.prefilter import PrefilterConfig, fit_feature_pool

OUT = RESULTS_DIR / "supplementary" / "baselines"
PROBES = Path(__file__).resolve().parents[1] / "data" / "mlh1_probes.tsv"
POLE, MSI, CN_LOW, CN_HIGH = range(4)

# Pathogenic POLE exonuclease-domain hotspot variants (Leon-Castillo et al., J Pathol 2020).
POLE_EDM_HOTSPOTS = {"p.P286R", "p.V411L", "p.S297F", "p.A456P", "p.S459F", "p.F367S", "p.L424I",
                     "p.M295R", "p.P436R", "p.M444K", "p.D368Y"}
MMR_GENES = ["MLH1", "MSH2", "MSH6", "PMS2"]
MLH1_TSS = 36993518        # NM_000249.4 (RefSeq Select), hg38, + strand, 1-based
MLH1_WINDOW = 500          # promoter probes: within +-500 bp of the transcription start site
MLH1_THRESHOLDS = (0.2, 0.3, 0.4)
MLH1_THRESHOLD = 0.3       # main definition of promoter hypermethylation (mean beta)
BLOCKS = ["rna", "mirna", "meth", "cnv", "mut"]


def metrics(y, pred, proba=None) -> dict:
    d = {"macro_f1": f1_score(y, pred, average="macro"), "accuracy": accuracy_score(y, pred),
         "macro_auc": roc_auc_score(y, proba, multi_class="ovr", average="macro") if proba is not None else np.nan}
    for c, v in zip(CLASS_NAMES, f1_score(y, pred, average=None, labels=range(4))):
        d["f1_" + c] = v
    return d


def lr_score(X_tr, y_tr, X_te, y_te) -> dict:
    sc = StandardScaler().fit(X_tr)
    clf = build_classifier("LogisticRegression", 0).fit(sc.transform(X_tr), y_tr)
    Xs = sc.transform(X_te)
    return metrics(y_te, clf.predict(Xs), clf.predict_proba(Xs))


def surrogate_indicators(ds) -> tuple[pd.DataFrame, dict]:
    """Label-free patient-level indicators mirroring POLE sequencing, MMR and p53 immunohistochemistry."""
    pats = list(ds.patients)
    mut = pd.read_csv(RAW_DIR / MUTATION_FILE, sep="\t", usecols=["sample", "gene", "Amino_Acid_Change"], dtype=str)
    chosen = pick_primary_samples(sorted(mut["sample"].unique()), pats)
    s2p = {bc: p for p, bc in chosen.items()}
    pole = mut[(mut.gene == "POLE") & mut.Amino_Acid_Change.isin(POLE_EDM_HOTSPOTS) & mut["sample"].isin(s2p)]
    pole_pat = set(pole["sample"].map(s2p))
    mblk = ds.blocks["mut"]
    col = {g: list(mblk.features).index(g) for g in MMR_GENES + ["TP53"]}
    mmr_mut = mblk.X[:, [col[g] for g in MMR_GENES]].max(axis=1) > 0
    tp53 = mblk.X[:, col["TP53"]] > 0
    pm = pd.read_csv(PROBES, sep="\t")
    prom = pm[(pm.chromStart + 1 - MLH1_TSS).abs() <= MLH1_WINDOW].id.tolist()
    beta = pd.read_csv(CACHE_DIR / "mlh1_beta.tsv", sep="\t", index_col=0)
    chosen_m = pick_primary_samples(list(beta.columns), pats)
    beta = beta.loc[beta.index.intersection(prom), [chosen_m[p] for p in pats]]
    beta.columns = pats
    mlh1_mean = beta.mean(axis=0, skipna=True)
    ind = pd.DataFrame({"pole_edm": [p in pole_pat for p in pats], "mmr_mut": mmr_mut, "tp53_mut": tp53,
                        "mlh1_beta": mlh1_mean.values}, index=pats)
    ind["mlh1_meth"] = ind.mlh1_beta > MLH1_THRESHOLD
    ind["mmr_def"] = ind.mmr_mut | ind.mlh1_meth
    info = {"n_promoter_probes": len(beta), "promoter_probes": sorted(beta.index),
            "counts": {k: int(ind[k].sum()) for k in ["pole_edm", "mmr_mut", "mlh1_meth", "mmr_def", "tp53_mut"]}}
    return ind, info


def promise_rule(ind: pd.DataFrame, threshold: float = MLH1_THRESHOLD) -> np.ndarray:
    mmr = ind.mmr_mut.values | (ind.mlh1_beta.values > threshold)
    return np.where(ind.pole_edm, POLE, np.where(mmr, MSI, np.where(ind.tp53_mut, CN_HIGH, CN_LOW)))


def inner_noise(X, y, partitions=range(20)) -> tuple[float, float]:
    """SD of the inner 3-fold macro-F1 over random partitions, and mean SE (SD over folds / sqrt 3)."""
    means, ses = [], []
    for s in partitions:
        f = []
        for tr, va in StratifiedKFold(3, shuffle=True, random_state=s).split(X, y):
            sc = StandardScaler().fit(X[tr])
            clf = build_classifier("LogisticRegression", 0).fit(sc.transform(X[tr]), y[tr])
            f.append(f1_score(y[va], clf.predict(sc.transform(X[va])), average="macro"))
        means.append(np.mean(f))
        ses.append(np.std(f, ddof=1) / np.sqrt(3))
    return float(np.std(means, ddof=1)), float(np.mean(ses))


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    ds = load_dataset()
    ind, info = surrogate_indicators(ds)
    ind.assign(label=[CLASS_NAMES[i] for i in ds.y]).to_csv(OUT / "surrogate_indicators.tsv", sep="\t")
    S = ind[["pole_edm", "mmr_def", "tp53_mut"]].astype(float).values
    rows, noise, ranks = [], [], {}
    for k, (tr, te) in enumerate(outer_folds(ds)):
        y_tr, y_te = ds.y[tr], ds.y[te]

        def add(model, group, n, m):
            rows.append({"fold": k, "analysis": group, "model": model, "n_features": n, **m})

        pool = fit_feature_pool(ds, tr, PrefilterConfig(k_per_block=500))
        X_tr, X_te = pool.transform(ds, tr), pool.transform(ds, te)
        allc, sl = np.arange(pool.n_features), pool.block_slices
        add("full pool", "reference", len(allc), lr_score(X_tr, y_tr, X_te, y_te))
        F, _ = f_classif(X_tr, y_tr)
        order = np.argsort(-np.nan_to_num(F, nan=-1.0))
        c = order[:450]
        add("ANOVA top 450", "reference", 450, lr_score(X_tr[:, c], y_tr, X_te[:, c], y_te))
        for b in BLOCKS:
            c = allc[sl[b]]
            add(b, "single block", len(c), lr_score(X_tr[:, c], y_tr, X_te[:, c], y_te))
            c = np.setdiff1d(allc, allc[sl[b]])
            add("without " + b, "leave one block out", len(c), lr_score(X_tr[:, c], y_tr, X_te[:, c], y_te))
        for b in ["rna", "mirna", "meth", "cnv"]:
            c = np.concatenate([allc[sl["mut"]], allc[sl[b]], allc[sl["clin"]]])
            add(f"mut + {b}", "two blocks", len(c), lr_score(X_tr[:, c], y_tr, X_te[:, c], y_te))
        c = allc[sl["clin"]]
        add("clinical only", "omics only", len(c), lr_score(X_tr[:, c], y_tr, X_te[:, c], y_te))
        po = fit_feature_pool(ds, tr, PrefilterConfig(k_per_block=500, include_clinical=False))
        Xo_tr, Xo_te = po.transform(ds, tr), po.transform(ds, te)
        add("omics-only full pool", "omics only", po.n_features, lr_score(Xo_tr, y_tr, Xo_te, y_te))
        Fo, _ = f_classif(Xo_tr, y_tr)
        c = np.argsort(-np.nan_to_num(Fo, nan=-1.0))[:450]
        add("omics-only ANOVA top 450", "omics only", 450, lr_score(Xo_tr[:, c], y_tr, Xo_te[:, c], y_te))
        for thr in MLH1_THRESHOLDS:
            add(f"surrogate ProMisE rule (MLH1 > {thr:g})", "surrogate", 3, metrics(y_te, promise_rule(ind, thr)[te]))
        add("surrogate LR", "surrogate", 3, lr_score(S[tr], y_tr, S[te], y_te))
        rank = np.argsort(order) + 1
        ranks[k] = {n: int(rank[i]) for i, n in enumerate(pool.feature_names) if n.startswith("clin:")}
        sd_full, se_full = inner_noise(X_tr, y_tr)
        sd_450, se_450 = inner_noise(X_tr[:, order[:450]], y_tr)
        noise.append({"fold": k, "sd_partitions_full": sd_full, "se_inner_full": se_full,
                      "sd_partitions_anova450": sd_450, "se_inner_anova450": se_450})
        print(f"fold {k} done", flush=True)

    df = pd.DataFrame(rows)
    df.to_csv(OUT / "baselines_folds.tsv", sep="\t", index=False)
    cols = ["macro_f1", "macro_auc", "accuracy"] + ["f1_" + c for c in CLASS_NAMES]
    summ = df.groupby(["analysis", "model", "n_features"], sort=False)[cols].agg(["mean", "std"])
    summ.to_csv(OUT / "baselines_summary.tsv", sep="\t")
    pd.DataFrame(noise).to_csv(OUT / "inner_noise.tsv", sep="\t", index=False)
    info["clinical_anova_ranks"] = ranks
    info["rule_agreement_whole_cohort"] = float((promise_rule(ind) == ds.y).mean())
    json.dump(info, open(OUT / "surrogate_info.json", "w"), indent=1)
    pd.set_option("display.width", 250)
    print(summ[["macro_f1", "macro_auc", "accuracy"]].round(3).to_string())
    print("inner-estimate noise (mean over outer folds):", pd.DataFrame(noise).drop(columns="fold").mean().round(4).to_dict())
    print("surrogate indicators:", info["counts"], "| rule agreement with TCGA labels:", round(info["rule_agreement_whole_cohort"], 3))


if __name__ == "__main__":
    main()
