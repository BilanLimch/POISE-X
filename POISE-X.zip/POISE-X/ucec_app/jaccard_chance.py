"""
Chance reference for the run-to-run stability of the panels.

For every pair of runs of an instantiation, the expected Jaccard index of two
random panels of the same sizes drawn from the two runs' fold-specific
candidate pools (Monte Carlo over hypergeometric draws), averaged over the 190
pairs and compared with the observed mean pairwise Jaccard index.

    python -m ucec_app.jaccard_chance
"""

from __future__ import annotations

import glob
import itertools
import json

import numpy as np
import pandas as pd

from ucec_app.data import load_dataset
from ucec_app.nested_cv import RESULTS_DIR, outer_folds
from ucec_app.prefilter import PrefilterConfig, fit_feature_pool

N_DRAWS = 20_000


def main() -> None:
    ds = load_dataset()
    pools = {k: set(fit_feature_pool(ds, tr, PrefilterConfig(k_per_block=500)).feature_names)
             for k, (tr, _) in enumerate(outer_folds(ds))}
    runs: dict[str, list] = {}
    for f in glob.glob(str(RESULTS_DIR / "*" / "fold*_seed*.json")):
        r = json.load(open(f))
        runs.setdefault(r["algorithm"], []).append((r["fold"], set(r["selected_features"])))
    rng = np.random.default_rng(0)
    rows = []
    for alg, rr in sorted(runs.items()):
        observed, chance = [], []
        for (f1, s1), (f2, s2) in itertools.combinations(rr, 2):
            a, b = len(s1), len(s2)
            n1, n2 = len(pools[f1]), len(pools[f2])
            shared = len(pools[f1] & pools[f2])
            x = rng.hypergeometric(shared, n1 - shared, a, N_DRAWS)   # members of A in the shared part of the pools
            inter = rng.hypergeometric(x, n2 - x, b)                 # members of B that hit them
            chance.append(np.mean(inter / (a + b - inter)))
            observed.append(len(s1 & s2) / len(s1 | s2))
        rows.append({"algorithm": alg, "observed": np.mean(observed), "chance": np.mean(chance)})
    df = pd.DataFrame(rows)
    df["excess"] = df.observed - df.chance
    out = RESULTS_DIR / "summary" / "jaccard_chance.tsv"
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, sep="\t", index=False)
    print(df.round(3).to_string(index=False))


if __name__ == "__main__":
    main()
