"""
One unit of the nested-CV experiment:
    one algorithm  x  one outer fold  x  one repeat seed.

    python -m ucec_app.nested_cv --algorithm HHO --run 7
    (equivalently --fold 1 --seed 2712; see ``unit_from_run``)

Study protocol:
every algorithm gets 20 independent searches of 5,000 evaluations each,
indexed i = 0..19. Run i uses outer fold i // 4 (so each fold is covered
four times) and random seed 2026 + 98 * i (identical across
all algorithms, so run i of any two algorithms shares the same fold, the
same inner-CV partition and the same classifier seeds, and is a true paired
sample). The units (19 algorithms x 20 runs = 380) are independent and can
run in parallel (``run_all.sh``); each writes one JSON to
``results/<algorithm>/fold<k>_seed<s>.json`` and ``aggregate.py`` collects
them afterwards.

Protocol, all fixed here so every unit is identical except for the
algorithm / fold / seed it is told to run:
  * outer split: StratifiedKFold(5, shuffle, random_state=OUTER_SPLIT_SEED)
    -- ONE fixed partition shared by every algorithm and every repeat;
  * inside the outer training fold only: prefilter (ANOVA top-k per block),
    the (N+5)-dim search with the shared fitness (inner 3-fold CV whose
    partition, like the algorithm's own RNG, depends on ``seed``);
  * best individual -> decode -> z-score + classifiers refit on the whole
    outer training fold -> evaluated once on the untouched outer test fold.
"""

from __future__ import annotations

import argparse
import json
import os
import time
from pathlib import Path

import numpy as np
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler

from ucec_app.baselines import ALGORITHMS, STANDARD_MAX_FES, STANDARD_POP_SIZE
from ucec_app.data import CLASS_NAMES, UcecDataset, load_dataset
from ucec_app.feature_selection import (
    FitnessConfig, N_CLASSIFIERS, build_classifier, decode_chromosome,
    make_fitness_fn, resolve_classifier_ensemble,
)
from ucec_app.prefilter import PrefilterConfig, fit_feature_pool

OUTER_SPLIT_SEED = 0
K_OUTER = 5
K_INNER = 3        # inner stratified folds used by the fitness function
R_REPEATS = 4      # runs per outer fold -> 5 x 4 = 20 searches per algorithm
N_RUNS = K_OUTER * R_REPEATS
SEED_BASE, SEED_STEP = 2026, 98   # run i -> seed 2026 + 98*i 
ALPHA = 0.9
RESULTS_DIR = Path(os.environ.get("UCEC_RESULTS_DIR", Path(__file__).resolve().parents[1] / "results"))
CURVE_EVERY = 25  # record best-so-far every this many evaluations


def run_seed(i: int) -> int:
    return SEED_BASE + SEED_STEP * i


def unit_from_run(i: int) -> tuple[int, int]:
    """Run index i in 0..N_RUNS-1 -> (outer fold, random seed)."""
    if not 0 <= i < N_RUNS:
        raise ValueError(f"run index must be in 0..{N_RUNS - 1}, got {i}")
    return i // R_REPEATS, run_seed(i)


def outer_folds(ds: UcecDataset) -> list[tuple[np.ndarray, np.ndarray]]:
    skf = StratifiedKFold(n_splits=K_OUTER, shuffle=True, random_state=OUTER_SPLIT_SEED)
    return list(skf.split(np.zeros(ds.n), ds.y))


def _final_model_predict(clf_names, X_tr, y_tr, X_te, random_state):
    """Refit on the whole outer training fold; return (pred, proba) on the test fold."""
    scaler = StandardScaler().fit(X_tr)
    X_tr, X_te = scaler.transform(X_tr), scaler.transform(X_te)
    proba = np.zeros((X_te.shape[0], len(CLASS_NAMES)))
    for name in clf_names:
        clf = build_classifier(name, random_state).fit(X_tr, y_tr)
        p = clf.predict_proba(X_te)
        for j, c in enumerate(clf.classes_):
            proba[:, int(c)] += p[:, j]
    proba /= len(clf_names)
    return proba.argmax(axis=1), proba


def run_unit(algorithm: str, fold: int, seed: int, max_fes: int = STANDARD_MAX_FES,
             pop_size: int = STANDARD_POP_SIZE, k_per_block: int = 500,
             out_dir: Path = RESULTS_DIR, force: bool = False) -> dict:
    out_path = Path(out_dir) / algorithm / f"fold{fold}_seed{seed}.json"
    if out_path.exists() and not force:
        print(f"exists, skipping: {out_path}")
        return json.load(open(out_path))
    out_path.parent.mkdir(parents=True, exist_ok=True)

    t_start = time.time()
    ds = load_dataset()
    train_idx, test_idx = outer_folds(ds)[fold]
    y_tr, y_te = ds.y[train_idx], ds.y[test_idx]

    pool = fit_feature_pool(ds, train_idx, PrefilterConfig(k_per_block=k_per_block))
    X_tr, X_te = pool.transform(ds, train_idx), pool.transform(ds, test_idx)
    N = pool.n_features
    dim = N + N_CLASSIFIERS

    base_fitness = make_fitness_fn(X_tr, y_tr, FitnessConfig(n_features=N, alpha=ALPHA, k_inner=K_INNER, random_state=seed))
    curve: list[tuple[int, float]] = []
    state = {"evals": 0, "best": float("inf")}

    def fitness(x):
        f = base_fitness(x)
        state["evals"] += 1
        state["best"] = min(state["best"], f)
        if state["evals"] % CURVE_EVERY == 0 or state["evals"] == 1:
            curve.append((state["evals"], state["best"]))
        return f

    kwargs = dict(dim=dim, fitness_fn=fitness, max_fes=max_fes, seed=seed, pop_size=pop_size)
    t_search = time.time()
    best_x, best_f = ALGORITHMS[algorithm](**kwargs)
    search_seconds = time.time() - t_search
    curve.append((state["evals"], state["best"]))

    feat_mask, clf_mask = decode_chromosome(best_x, N)
    clf_names = resolve_classifier_ensemble(clf_mask, np.random.default_rng(seed))
    if feat_mask.sum() == 0:  # degenerate best individual; evaluate with all features so metrics exist
        feat_mask = np.ones(N, dtype=bool)
    pred, proba = _final_model_predict(clf_names, X_tr[:, feat_mask], y_tr, X_te[:, feat_mask], seed)

    selected = pool.feature_names[feat_mask]
    per_block = {b: int(feat_mask[s].sum()) for b, s in pool.block_slices.items()}
    result = {
        "algorithm": algorithm, "fold": fold, "seed": seed,
        "protocol": {"pop_size": pop_size, "max_fes": max_fes, "k_per_block": k_per_block,
                     "alpha": ALPHA, "k_inner": K_INNER, "k_outer": K_OUTER, "outer_split_seed": OUTER_SPLIT_SEED},
        "n_train": int(len(train_idx)), "n_test": int(len(test_idx)),
        "N": int(N), "dim": int(dim),
        "best_F": float(best_f), "evals_used": int(state["evals"]),
        "n_selected": int(feat_mask.sum()), "selected_per_block": per_block,
        "selected_features": selected.tolist(),
        "classifiers": clf_names, "classifier_mask": clf_mask.astype(int).tolist(),
        "test_metrics": {
            "macro_f1": float(f1_score(y_te, pred, average="macro")),
            "macro_auc": float(roc_auc_score(y_te, proba, multi_class="ovr", average="macro")),
            "accuracy": float(accuracy_score(y_te, pred)),
            "per_class_f1": dict(zip(CLASS_NAMES, f1_score(y_te, pred, average=None, labels=range(4)).tolist())),
        },
        "curve": curve,
        "search_seconds": search_seconds, "total_seconds": time.time() - t_start,
    }
    with open(out_path, "w") as f:
        json.dump(result, f, indent=1)
    m = result["test_metrics"]
    print(f"{algorithm} fold{fold} seed{seed}: F={best_f:.4f} |S|={feat_mask.sum()} clfs={clf_names} "
          f"test macro-F1={m['macro_f1']:.3f} AUC={m['macro_auc']:.3f} acc={m['accuracy']:.3f} "
          f"[{search_seconds/60:.1f} min search]")
    return result


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--algorithm", required=True, choices=list(ALGORITHMS))
    ap.add_argument("--run", type=int, help=f"run index 0..{N_RUNS - 1}: sets --fold and --seed per protocol")
    ap.add_argument("--fold", type=int)
    ap.add_argument("--seed", type=int)
    ap.add_argument("--max-fes", type=int, default=STANDARD_MAX_FES)
    ap.add_argument("--pop-size", type=int, default=STANDARD_POP_SIZE)
    ap.add_argument("--k-per-block", type=int, default=500)
    ap.add_argument("--out", type=Path, default=RESULTS_DIR)
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args()
    if a.run is not None:
        a.fold, a.seed = unit_from_run(a.run)
    elif a.fold is None or a.seed is None:
        ap.error("give --run, or both --fold and --seed")
    run_unit(a.algorithm, a.fold, a.seed, a.max_fes, a.pop_size, a.k_per_block, a.out, a.force)
