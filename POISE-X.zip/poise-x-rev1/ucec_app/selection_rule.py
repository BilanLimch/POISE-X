"""
Leave-one-fold-out evaluation of the configuration-selection rule
(Sections 3.8 and 4.7, Table S1).

The rule: take the instantiation with the highest mean outer-test macro-F1 as
reference, compare it with every other instantiation by two-sided paired
Wilcoxon tests (Holm-corrected), and among those with adjusted p >= 0.05 choose
the one with the lowest mean search objective. For each outer fold k the rule
is applied to the runs of the other four folds, and the chosen configuration is
scored on fold k (mean of its four runs there). Reads
``results/summary/runs.tsv`` written by ``ucec_app.aggregate``.

    python -m ucec_app.selection_rule
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon

from ucec_app.nested_cv import RESULTS_DIR

SUMMARY_DIR = RESULTS_DIR / "summary"


def holm(p) -> np.ndarray:
    p = np.asarray(p, dtype=float)
    order, m = np.argsort(p), len(p)
    adj, running = np.empty(m), 0.0
    for r, i in enumerate(order):
        running = max(running, (m - r) * p[i])
        adj[i] = min(1.0, running)
    return adj


def apply_rule(runs: pd.DataFrame) -> tuple[str, list[str], str, dict]:
    piv = runs.pivot_table(index=["fold", "seed"], columns="algorithm", values="macro_f1")
    ref = piv.mean().idxmax()
    others = [a for a in piv.columns if a != ref]
    adj = dict(zip(others, holm([wilcoxon(piv[ref], piv[a]).pvalue for a in others])))
    group = [ref] + sorted(a for a in others if adj[a] >= 0.05)
    objective = runs.groupby("algorithm").best_F.mean()
    return ref, group, objective[group].idxmin(), {**adj, "objective": objective}


def main() -> None:
    runs = pd.read_csv(SUMMARY_DIR / "runs.tsv", sep="\t")
    ref, group, chosen, _ = apply_rule(runs)
    print(f"all folds: reference {ref}, group {group}, chosen {chosen}")
    rows = []
    for k in sorted(runs.fold.unique()):
        ref, group, chosen, extra = apply_rule(runs[runs.fold != k])
        held_out = runs[runs.fold == k].groupby("algorithm").macro_f1.mean()
        rows.append({"fold": k, "reference": ref, "group": ", ".join(group), "chosen": chosen,
                     "objective_chosen": extra["objective"][chosen], "f1_rule": held_out[chosen],
                     "f1_reference": held_out[ref], "f1_GWO": held_out.get("GWO", np.nan)})
    df = pd.DataFrame(rows)
    df.to_csv(SUMMARY_DIR / "selection_rule_lofo.tsv", sep="\t", index=False)
    print(df.round(3).to_string(index=False))
    for c in ["f1_rule", "f1_reference", "f1_GWO"]:
        print(f"{c}: {df[c].mean():.3f} +/- {df[c].std(ddof=1):.3f}")


if __name__ == "__main__":
    main()
