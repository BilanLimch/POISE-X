"""Validation of "consensus" feature panels (no ranking uses the test rows it is scored on).

Question: do the features that an instantiation selects most often form a
useful fixed panel?  For each outer fold k:
  1. take the runs *of fold k itself* (4 seeds for one instantiation, 4 x 19 =
     76 for the all-instantiation consensus).  Only these runs were searched
     without access to fold k's test patients; runs of the other folds trained
     on data that includes fold k's test rows, so using them would leak
     (option --scope other-folds reproduces that leaky variant for reference),
  2. rank the features of fold k's candidate pool by how many of those runs
     selected them (ties broken by the mean best fitness of the runs that
     selected the feature, then by name),
  3. keep the top-k features for several k,
  4. train the reference classifier (logistic regression, z-scored inside the
     training fold) on fold k's training rows and score fold k's test rows.
Two comparators of the same size: the top-k of the fold-internal ANOVA F
ranking (a pure filter) and the mean over random panels drawn from the pool.
Nothing in step 2 uses fold k's test rows.

    python -m ucec_app.consensus_validation --alg GWO --alg ALL
"""
from __future__ import annotations

import argparse
import glob
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.feature_selection import f_classif
from sklearn.metrics import f1_score, roc_auc_score
from sklearn.preprocessing import StandardScaler

from ucec_app.baselines import ALGORITHMS
from ucec_app.data import load_dataset
from ucec_app.feature_selection import build_classifier
from ucec_app.nested_cv import RESULTS_DIR, outer_folds
from ucec_app.prefilter import PrefilterConfig, fit_feature_pool

SIZES = [10, 20, 50, 100, 200, 300, 450, 600, 1000, 1500, 2505]
N_RANDOM = 20


def load_records(results_dir: Path) -> list[dict]:
    recs = []
    for f in glob.glob(str(results_dir / "*" / "fold*_seed*.json")):
        r = json.load(open(f))
        recs.append({"algorithm": r["algorithm"], "fold": r["fold"], "best_F": r["best_F"],
                     "selected": set(r["selected_features"])})
    return recs


def consensus_ranking(recs: list[dict], pool_names: np.ndarray) -> list[str]:
    count, fsum = defaultdict(int), defaultdict(float)
    for r in recs:
        for f in r["selected"]:
            count[f] += 1
            fsum[f] += r["best_F"]
    names = list(pool_names)
    return sorted(names, key=lambda f: (-count.get(f, 0), fsum.get(f, 0.0) / max(count.get(f, 0), 1), f))


def score(clf_name: str, X_tr, y_tr, X_te, y_te, seed: int) -> tuple[float, float]:
    sc = StandardScaler().fit(X_tr)
    clf = build_classifier(clf_name, seed).fit(sc.transform(X_tr), y_tr)
    Xs = sc.transform(X_te)
    pred = clf.predict(Xs)
    proba = clf.predict_proba(Xs)
    return f1_score(y_te, pred, average="macro"), roc_auc_score(y_te, proba, multi_class="ovr", average="macro")


def main(algs: list[str], results_dir: Path, out: Path, scope: str = "same-fold", clf_name: str = "LogisticRegression") -> None:
    ds = load_dataset()
    folds = outer_folds(ds)
    recs = load_records(results_dir)
    rows = []
    for k, (tr, te) in enumerate(folds):
        pool = fit_feature_pool(ds, tr, PrefilterConfig(k_per_block=500))
        X_tr, X_te = pool.transform(ds, tr), pool.transform(ds, te)
        y_tr, y_te = ds.y[tr], ds.y[te]
        names = pool.feature_names
        idx = {f: i for i, f in enumerate(names)}
        # comparator rankings (fold-internal, label-dependent on training rows only)
        F, _ = f_classif(X_tr, y_tr)
        anova_rank = [names[i] for i in np.argsort(-np.nan_to_num(F, nan=-1.0))]
        rng = np.random.default_rng(k)
        rankings = {"ANOVA filter": anova_rank}
        for a in algs:
            keep = (lambda r: r["fold"] == k) if scope == "same-fold" else (lambda r: r["fold"] != k)
            sub = [r for r in recs if keep(r) and (a == "ALL" or r["algorithm"] == a)]
            rankings[f"consensus {a}"] = consensus_ranking(sub, names)
        for size in SIZES:
            size = min(size, len(names))
            for label, rank in rankings.items():
                cols = [idx[f] for f in rank[:size]]
                f1, auc = score(clf_name, X_tr[:, cols], y_tr, X_te[:, cols], y_te, seed=0)
                rows.append({"fold": k, "size": size, "panel": label, "macro_f1": f1, "macro_auc": auc})
            f1s, aucs = [], []
            for j in range(N_RANDOM):
                cols = rng.choice(len(names), size=size, replace=False)
                f1, auc = score(clf_name, X_tr[:, cols], y_tr, X_te[:, cols], y_te, seed=0)
                f1s.append(f1); aucs.append(auc)
            rows.append({"fold": k, "size": size, "panel": "random", "macro_f1": float(np.mean(f1s)), "macro_auc": float(np.mean(aucs))})
            print(f"fold {k} size {size:4d}: " + "  ".join(f"{r['panel']}={r['macro_f1']:.3f}" for r in rows[-(len(rankings) + 1):]), flush=True)
    df = pd.DataFrame(rows)
    out.mkdir(parents=True, exist_ok=True)
    df.to_csv(out / f"consensus_validation_{scope}_runs.tsv", sep="\t", index=False)
    summ = df.groupby(["panel", "size"])[["macro_f1", "macro_auc"]].agg(["mean", "std"]).round(3)
    summ.to_csv(out / f"consensus_validation_{scope}_summary.tsv", sep="\t")
    print(summ.to_string())


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--alg", action="append", default=None, help="instantiation(s) to build the consensus from; ALL = every instantiation")
    ap.add_argument("--results", type=Path, default=RESULTS_DIR)
    ap.add_argument("--out", type=Path, default=RESULTS_DIR / "summary")
    ap.add_argument("--scope", choices=["same-fold", "other-folds"], default="same-fold")
    a = ap.parse_args()
    main(a.alg or ["GWO", "ALL"], a.results, a.out, a.scope)
